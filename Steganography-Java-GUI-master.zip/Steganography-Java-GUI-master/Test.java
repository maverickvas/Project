
public class Test {
    
    /** Creates a new instance of Test */
    public Test() {
    }
    
}
